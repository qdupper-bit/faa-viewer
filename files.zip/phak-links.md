# PHAK Quick Links — copy sheet
FAA-H-8083-25C · every main section → viewer deep link. Paste into lesson embeds (snippet B `data-src`) or anywhere else.

## Ch. 1 — Introduction to Flying
- Introduction (1-1): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/03_phak_ch1.pdf&page=1&title=PHAK%20Ch.1%20-%20Introduction
- History of Flight (1-2): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/03_phak_ch1.pdf&page=2&title=PHAK%20Ch.1%20-%20History%20of%20Flight
- History of the Federal Aviation Administration (FAA) (1-3): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/03_phak_ch1.pdf&page=3&title=PHAK%20Ch.1%20-%20History%20of%20the%20Federal%20Aviation%20Administration%20%28FAA%29
- The Role of the FAA (1-7): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/03_phak_ch1.pdf&page=7&title=PHAK%20Ch.1%20-%20The%20Role%20of%20the%20FAA
- Aircraft Classifications and Ultralight Vehicles (1-14): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/03_phak_ch1.pdf&page=14&title=PHAK%20Ch.1%20-%20Aircraft%20Classifications%20and%20Ultralight%20Vehicles
- Pilot Certifications (1-16): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/03_phak_ch1.pdf&page=16&title=PHAK%20Ch.1%20-%20Pilot%20Certifications
- Selecting a Flight School (1-18): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/03_phak_ch1.pdf&page=18&title=PHAK%20Ch.1%20-%20Selecting%20a%20Flight%20School
- The Student Pilot (1-20): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/03_phak_ch1.pdf&page=20&title=PHAK%20Ch.1%20-%20The%20Student%20Pilot
- Becoming a Pilot (1-21): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/03_phak_ch1.pdf&page=21&title=PHAK%20Ch.1%20-%20Becoming%20a%20Pilot
- Knowledge and Skill Tests (1-21): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/03_phak_ch1.pdf&page=21&title=PHAK%20Ch.1%20-%20Knowledge%20and%20Skill%20Tests
- Chapter Summary (1-24): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/03_phak_ch1.pdf&page=24&title=PHAK%20Ch.1%20-%20Chapter%20Summary

## Ch. 2 — Aeronautical Decision-Making
- Introduction (2-1): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/04_phak_ch2.pdf&page=1&title=PHAK%20Ch.2%20-%20Introduction
- History of ADM (2-2): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/04_phak_ch2.pdf&page=2&title=PHAK%20Ch.2%20-%20History%20of%20ADM
- Risk Management (2-3): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/04_phak_ch2.pdf&page=3&title=PHAK%20Ch.2%20-%20Risk%20Management
- Crew Resource Management (CRM) and Single-Pilot Resource Management (2-4): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/04_phak_ch2.pdf&page=4&title=PHAK%20Ch.2%20-%20Crew%20Resource%20Management%20%28CRM%29%20and%20Single-Pilot%20Resource%20Management
- Hazard and Risk (2-4): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/04_phak_ch2.pdf&page=4&title=PHAK%20Ch.2%20-%20Hazard%20and%20Risk
- Human Factors (2-10): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/04_phak_ch2.pdf&page=10&title=PHAK%20Ch.2%20-%20Human%20Factors
- Human Behavior (2-11): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/04_phak_ch2.pdf&page=11&title=PHAK%20Ch.2%20-%20Human%20Behavior
- The Decision-Making Process (2-12): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/04_phak_ch2.pdf&page=12&title=PHAK%20Ch.2%20-%20The%20Decision-Making%20Process
- Decision-Making in a Dynamic Environment (2-21): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/04_phak_ch2.pdf&page=21&title=PHAK%20Ch.2%20-%20Decision-Making%20in%20a%20Dynamic%20Environment
- Situational Awareness (2-24): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/04_phak_ch2.pdf&page=24&title=PHAK%20Ch.2%20-%20Situational%20Awareness
- Automation (2-25): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/04_phak_ch2.pdf&page=25&title=PHAK%20Ch.2%20-%20Automation
- Chapter Summary (2-32): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/04_phak_ch2.pdf&page=32&title=PHAK%20Ch.2%20-%20Chapter%20Summary

## Ch. 3 — Aircraft Construction
- Introduction (3-1): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/05_phak_ch3.pdf&page=1&title=PHAK%20Ch.3%20-%20Introduction
- Aircraft Design, Certification, and Airworthiness (3-2): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/05_phak_ch3.pdf&page=2&title=PHAK%20Ch.3%20-%20Aircraft%20Design%2C%20Certification%2C%20and%20Airworthiness
- Lift and Basic Aerodynamics (3-2): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/05_phak_ch3.pdf&page=2&title=PHAK%20Ch.3%20-%20Lift%20and%20Basic%20Aerodynamics
- Major Components (3-3): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/05_phak_ch3.pdf&page=3&title=PHAK%20Ch.3%20-%20Major%20Components
- Subcomponents (3-8): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/05_phak_ch3.pdf&page=8&title=PHAK%20Ch.3%20-%20Subcomponents
- Types of Aircraft Construction (3-8): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/05_phak_ch3.pdf&page=8&title=PHAK%20Ch.3%20-%20Types%20of%20Aircraft%20Construction
- Instrumentation: Moving into the Future (3-12): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/05_phak_ch3.pdf&page=12&title=PHAK%20Ch.3%20-%20Instrumentation%3A%20Moving%20into%20the%20Future
- Global Positioning System (GPS) (3-13): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/05_phak_ch3.pdf&page=13&title=PHAK%20Ch.3%20-%20Global%20Positioning%20System%20%28GPS%29
- Chapter Summary (3-13): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/05_phak_ch3.pdf&page=13&title=PHAK%20Ch.3%20-%20Chapter%20Summary

## Ch. 4 — Principles of Flight
- Introduction (4-1): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/06_phak_ch4.pdf&page=1&title=PHAK%20Ch.4%20-%20Introduction
- Structure of the Atmosphere (4-1): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/06_phak_ch4.pdf&page=1&title=PHAK%20Ch.4%20-%20Structure%20of%20the%20Atmosphere
- Theories in the Production of Lift (4-5): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/06_phak_ch4.pdf&page=5&title=PHAK%20Ch.4%20-%20Theories%20in%20the%20Production%20of%20Lift
- Airfoil Design (4-6): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/06_phak_ch4.pdf&page=6&title=PHAK%20Ch.4%20-%20Airfoil%20Design
- A Third Dimension (4-9): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/06_phak_ch4.pdf&page=9&title=PHAK%20Ch.4%20-%20A%20Third%20Dimension
- Chapter Summary (4-9): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/06_phak_ch4.pdf&page=9&title=PHAK%20Ch.4%20-%20Chapter%20Summary

## Ch. 5 — Aerodynamics of Flight
- Forces Acting on the Aircraft (5-1): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/07_phak_ch5.pdf&page=1&title=PHAK%20Ch.5%20-%20Forces%20Acting%20on%20the%20Aircraft
- Wingtip Vortices (5-8): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/07_phak_ch5.pdf&page=8&title=PHAK%20Ch.5%20-%20Wingtip%20Vortices
- Ground Effect (5-11): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/07_phak_ch5.pdf&page=11&title=PHAK%20Ch.5%20-%20Ground%20Effect
- Axes of an Aircraft (5-12): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/07_phak_ch5.pdf&page=12&title=PHAK%20Ch.5%20-%20Axes%20of%20an%20Aircraft
- Moment and Moment Arm (5-13): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/07_phak_ch5.pdf&page=13&title=PHAK%20Ch.5%20-%20Moment%20and%20Moment%20Arm
- Aircraft Design Characteristics (5-14): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/07_phak_ch5.pdf&page=14&title=PHAK%20Ch.5%20-%20Aircraft%20Design%20Characteristics
- Effect of Wing Planform (5-20): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/07_phak_ch5.pdf&page=20&title=PHAK%20Ch.5%20-%20Effect%20of%20Wing%20Planform
- Aerodynamic Forces in Flight Maneuvers (5-22): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/07_phak_ch5.pdf&page=22&title=PHAK%20Ch.5%20-%20Aerodynamic%20Forces%20in%20Flight%20Maneuvers
- Stalls (5-25): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/07_phak_ch5.pdf&page=25&title=PHAK%20Ch.5%20-%20Stalls
- Angle of Attack Indicators (5-26): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/07_phak_ch5.pdf&page=26&title=PHAK%20Ch.5%20-%20Angle%20of%20Attack%20Indicators
- Basic Propeller Principles (5-28): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/07_phak_ch5.pdf&page=28&title=PHAK%20Ch.5%20-%20Basic%20Propeller%20Principles
- Load Factors (5-33): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/07_phak_ch5.pdf&page=33&title=PHAK%20Ch.5%20-%20Load%20Factors
- Weight and Balance (5-40): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/07_phak_ch5.pdf&page=40&title=PHAK%20Ch.5%20-%20Weight%20and%20Balance
- High Speed Flight (5-44): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/07_phak_ch5.pdf&page=44&title=PHAK%20Ch.5%20-%20High%20Speed%20Flight
- Chapter Summary (5-51): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/07_phak_ch5.pdf&page=51&title=PHAK%20Ch.5%20-%20Chapter%20Summary

## Ch. 6 — Flight Controls
- Introduction (6-1): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/08_phak_ch6.pdf&page=1&title=PHAK%20Ch.6%20-%20Introduction
- Flight Control Systems (6-2): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/08_phak_ch6.pdf&page=2&title=PHAK%20Ch.6%20-%20Flight%20Control%20Systems
- Autopilot (6-12): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/08_phak_ch6.pdf&page=12&title=PHAK%20Ch.6%20-%20Autopilot
- Chapter Summary (6-12): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/08_phak_ch6.pdf&page=12&title=PHAK%20Ch.6%20-%20Chapter%20Summary

## Ch. 7 — Aircraft Systems
- Introduction (7-1): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/09_phak_ch7.pdf&page=1&title=PHAK%20Ch.7%20-%20Introduction
- Powerplant (7-1): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/09_phak_ch7.pdf&page=1&title=PHAK%20Ch.7%20-%20Powerplant
- Superchargers and Turbosuperchargers (7-12): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/09_phak_ch7.pdf&page=12&title=PHAK%20Ch.7%20-%20Superchargers%20and%20Turbosuperchargers
- Ignition System (7-15): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/09_phak_ch7.pdf&page=15&title=PHAK%20Ch.7%20-%20Ignition%20System
- Oil Systems (7-16): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/09_phak_ch7.pdf&page=16&title=PHAK%20Ch.7%20-%20Oil%20Systems
- Engine Cooling Systems (7-17): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/09_phak_ch7.pdf&page=17&title=PHAK%20Ch.7%20-%20Engine%20Cooling%20Systems
- Exhaust Systems (7-18): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/09_phak_ch7.pdf&page=18&title=PHAK%20Ch.7%20-%20Exhaust%20Systems
- Starting System (7-18): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/09_phak_ch7.pdf&page=18&title=PHAK%20Ch.7%20-%20Starting%20System
- Combustion (7-18): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/09_phak_ch7.pdf&page=18&title=PHAK%20Ch.7%20-%20Combustion
- Full Authority Digital Engine Control (FADEC) (7-20): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/09_phak_ch7.pdf&page=20&title=PHAK%20Ch.7%20-%20Full%20Authority%20Digital%20Engine%20Control%20%28FADEC%29
- Turbine Engines (7-20): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/09_phak_ch7.pdf&page=20&title=PHAK%20Ch.7%20-%20Turbine%20Engines
- Airframe Systems (7-25): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/09_phak_ch7.pdf&page=25&title=PHAK%20Ch.7%20-%20Airframe%20Systems
- Fuel Systems (7-25): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/09_phak_ch7.pdf&page=25&title=PHAK%20Ch.7%20-%20Fuel%20Systems
- Refueling Procedures (7-29): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/09_phak_ch7.pdf&page=29&title=PHAK%20Ch.7%20-%20Refueling%20Procedures
- Heating System (7-29): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/09_phak_ch7.pdf&page=29&title=PHAK%20Ch.7%20-%20Heating%20System
- Electrical System (7-30): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/09_phak_ch7.pdf&page=30&title=PHAK%20Ch.7%20-%20Electrical%20System
- Hydraulic Systems (7-31): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/09_phak_ch7.pdf&page=31&title=PHAK%20Ch.7%20-%20Hydraulic%20Systems
- Pressurized Aircraft (7-34): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/09_phak_ch7.pdf&page=34&title=PHAK%20Ch.7%20-%20Pressurized%20Aircraft
- Oxygen Systems (7-37): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/09_phak_ch7.pdf&page=37&title=PHAK%20Ch.7%20-%20Oxygen%20Systems
- Anti-Ice and Deice Systems (7-40): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/09_phak_ch7.pdf&page=40&title=PHAK%20Ch.7%20-%20Anti-Ice%20and%20Deice%20Systems
- Chapter Summary (7-41): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/09_phak_ch7.pdf&page=41&title=PHAK%20Ch.7%20-%20Chapter%20Summary

## Ch. 8 — Flight Instruments
- Introduction (8-1): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/10_phak_ch8.pdf&page=1&title=PHAK%20Ch.8%20-%20Introduction
- Pitot-Static Flight Instruments (8-1): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/10_phak_ch8.pdf&page=1&title=PHAK%20Ch.8%20-%20Pitot-Static%20Flight%20Instruments
- Electronic Flight Display (EFD) (8-12): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/10_phak_ch8.pdf&page=12&title=PHAK%20Ch.8%20-%20Electronic%20Flight%20Display%20%28EFD%29
- Gyroscopic Flight Instruments (8-15): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/10_phak_ch8.pdf&page=15&title=PHAK%20Ch.8%20-%20Gyroscopic%20Flight%20Instruments
- Angle of Attack Indicators (8-22): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/10_phak_ch8.pdf&page=22&title=PHAK%20Ch.8%20-%20Angle%20of%20Attack%20Indicators
- Compass Systems (8-23): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/10_phak_ch8.pdf&page=23&title=PHAK%20Ch.8%20-%20Compass%20Systems
- Outside Air Temperature (OAT) Gauge (8-28): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/10_phak_ch8.pdf&page=28&title=PHAK%20Ch.8%20-%20Outside%20Air%20Temperature%20%28OAT%29%20Gauge
- Chapter Summary (8-28): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/10_phak_ch8.pdf&page=28&title=PHAK%20Ch.8%20-%20Chapter%20Summary

## Ch. 9 — Flight Manuals and Other Documents
- Introduction (9-1): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/11_phak_ch9.pdf&page=1&title=PHAK%20Ch.9%20-%20Introduction
- Preliminary Pages (9-2): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/11_phak_ch9.pdf&page=2&title=PHAK%20Ch.9%20-%20Preliminary%20Pages
- General (Section 1) (9-2): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/11_phak_ch9.pdf&page=2&title=PHAK%20Ch.9%20-%20General%20%28Section%201%29
- Limitations (Section 2) (9-2): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/11_phak_ch9.pdf&page=2&title=PHAK%20Ch.9%20-%20Limitations%20%28Section%202%29
- Emergency Procedures (Section 3) (9-4): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/11_phak_ch9.pdf&page=4&title=PHAK%20Ch.9%20-%20Emergency%20Procedures%20%28Section%203%29
- Normal Procedures (Section 4) (9-4): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/11_phak_ch9.pdf&page=4&title=PHAK%20Ch.9%20-%20Normal%20Procedures%20%28Section%204%29
- Performance (Section 5) (9-4): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/11_phak_ch9.pdf&page=4&title=PHAK%20Ch.9%20-%20Performance%20%28Section%205%29
- Weight and Balance/Equipment List (Section 6) (9-4): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/11_phak_ch9.pdf&page=4&title=PHAK%20Ch.9%20-%20Weight%20and%20Balance%2FEquipment%20List%20%28Section%206%29
- Systems Description (Section 7) (9-4): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/11_phak_ch9.pdf&page=4&title=PHAK%20Ch.9%20-%20Systems%20Description%20%28Section%207%29
- Handling, Service, and Maintenance (Section 8) (9-5): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/11_phak_ch9.pdf&page=5&title=PHAK%20Ch.9%20-%20Handling%2C%20Service%2C%20and%20Maintenance%20%28Section%208%29
- Supplements (Section 9) (9-5): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/11_phak_ch9.pdf&page=5&title=PHAK%20Ch.9%20-%20Supplements%20%28Section%209%29
- Safety Tips (Section 10) (9-6): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/11_phak_ch9.pdf&page=6&title=PHAK%20Ch.9%20-%20Safety%20Tips%20%28Section%2010%29
- Aircraft Documents (9-6): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/11_phak_ch9.pdf&page=6&title=PHAK%20Ch.9%20-%20Aircraft%20Documents
- Aircraft Inspections (9-8): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/11_phak_ch9.pdf&page=8&title=PHAK%20Ch.9%20-%20Aircraft%20Inspections
- Minimum Equipment Lists (MEL) and Operations With Inoperative Equipment (9-9): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/11_phak_ch9.pdf&page=9&title=PHAK%20Ch.9%20-%20Minimum%20Equipment%20Lists%20%28MEL%29%20and%20Operations%20With%20Inoperative%20Equipment
- Preventive Maintenance (9-10): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/11_phak_ch9.pdf&page=10&title=PHAK%20Ch.9%20-%20Preventive%20Maintenance
- Repairs and Alterations (9-12): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/11_phak_ch9.pdf&page=12&title=PHAK%20Ch.9%20-%20Repairs%20and%20Alterations
- Special Flight Permits (9-12): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/11_phak_ch9.pdf&page=12&title=PHAK%20Ch.9%20-%20Special%20Flight%20Permits
- Airworthiness Directives (ADs) (9-12): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/11_phak_ch9.pdf&page=12&title=PHAK%20Ch.9%20-%20Airworthiness%20Directives%20%28ADs%29
- Aircraft Owner/Operator Responsibilities (9-13): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/11_phak_ch9.pdf&page=13&title=PHAK%20Ch.9%20-%20Aircraft%20Owner%2FOperator%20Responsibilities
- Chapter Summary (9-13): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/11_phak_ch9.pdf&page=13&title=PHAK%20Ch.9%20-%20Chapter%20Summary

## Ch. 10 — Weight and Balance
- Introduction (10-1): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/12_phak_ch10.pdf&page=1&title=PHAK%20Ch.10%20-%20Introduction
- Weight Control (10-1): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/12_phak_ch10.pdf&page=1&title=PHAK%20Ch.10%20-%20Weight%20Control
- Balance, Stability, and Center of Gravity (10-2): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/12_phak_ch10.pdf&page=2&title=PHAK%20Ch.10%20-%20Balance%2C%20Stability%2C%20and%20Center%20of%20Gravity
- Determining Loaded Weight and CG (10-7): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/12_phak_ch10.pdf&page=7&title=PHAK%20Ch.10%20-%20Determining%20Loaded%20Weight%20and%20CG
- Chapter Summary (10-11): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/12_phak_ch10.pdf&page=11&title=PHAK%20Ch.10%20-%20Chapter%20Summary

## Ch. 11 — Aircraft Performance
- Introduction (11-1): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/13_phak_ch11.pdf&page=1&title=PHAK%20Ch.11%20-%20Introduction
- Importance of Performance Data (11-1): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/13_phak_ch11.pdf&page=1&title=PHAK%20Ch.11%20-%20Importance%20of%20Performance%20Data
- Structure of the Atmosphere (11-2): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/13_phak_ch11.pdf&page=2&title=PHAK%20Ch.11%20-%20Structure%20of%20the%20Atmosphere
- Atmospheric Pressure (11-2): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/13_phak_ch11.pdf&page=2&title=PHAK%20Ch.11%20-%20Atmospheric%20Pressure
- Pressure Altitude (11-3): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/13_phak_ch11.pdf&page=3&title=PHAK%20Ch.11%20-%20Pressure%20Altitude
- Density Altitude (11-3): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/13_phak_ch11.pdf&page=3&title=PHAK%20Ch.11%20-%20Density%20Altitude
- Performance (11-5): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/13_phak_ch11.pdf&page=5&title=PHAK%20Ch.11%20-%20Performance
- Performance Speeds (11-18): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/13_phak_ch11.pdf&page=18&title=PHAK%20Ch.11%20-%20Performance%20Speeds
- Performance Charts (11-19): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/13_phak_ch11.pdf&page=19&title=PHAK%20Ch.11%20-%20Performance%20Charts
- Transport Category Aircraft Performance (11-28): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/13_phak_ch11.pdf&page=28&title=PHAK%20Ch.11%20-%20Transport%20Category%20Aircraft%20Performance
- Air Carrier Obstacle Clearance Requirements (11-28): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/13_phak_ch11.pdf&page=28&title=PHAK%20Ch.11%20-%20Air%20Carrier%20Obstacle%20Clearance%20Requirements
- Chapter Summary (11-28): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/13_phak_ch11.pdf&page=28&title=PHAK%20Ch.11%20-%20Chapter%20Summary

## Ch. 12 — Weather Theory
- Introduction (12-1): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/14_phak_ch12.pdf&page=1&title=PHAK%20Ch.12%20-%20Introduction
- Atmosphere (12-2): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/14_phak_ch12.pdf&page=2&title=PHAK%20Ch.12%20-%20Atmosphere
- Coriolis Force (12-3): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/14_phak_ch12.pdf&page=3&title=PHAK%20Ch.12%20-%20Coriolis%20Force
- Measurement of Atmosphere Pressure (12-4): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/14_phak_ch12.pdf&page=4&title=PHAK%20Ch.12%20-%20Measurement%20of%20Atmosphere%20Pressure
- Altitude and Atmospheric Pressure (12-5): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/14_phak_ch12.pdf&page=5&title=PHAK%20Ch.12%20-%20Altitude%20and%20Atmospheric%20Pressure
- Altitude and Flight (12-6): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/14_phak_ch12.pdf&page=6&title=PHAK%20Ch.12%20-%20Altitude%20and%20Flight
- Altitude and the Human Body (12-6): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/14_phak_ch12.pdf&page=6&title=PHAK%20Ch.12%20-%20Altitude%20and%20the%20Human%20Body
- Wind and Currents (12-7): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/14_phak_ch12.pdf&page=7&title=PHAK%20Ch.12%20-%20Wind%20and%20Currents
- Atmospheric Stability (12-12): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/14_phak_ch12.pdf&page=12&title=PHAK%20Ch.12%20-%20Atmospheric%20Stability
- Air Masses (12-17): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/14_phak_ch12.pdf&page=17&title=PHAK%20Ch.12%20-%20Air%20Masses
- Fronts (12-18): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/14_phak_ch12.pdf&page=18&title=PHAK%20Ch.12%20-%20Fronts
- Thunderstorms (12-22): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/14_phak_ch12.pdf&page=22&title=PHAK%20Ch.12%20-%20Thunderstorms
- Chapter Summary (12-25): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/14_phak_ch12.pdf&page=25&title=PHAK%20Ch.12%20-%20Chapter%20Summary

## Ch. 13 — Aviation Weather Services
- Introduction (13-1): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/15_phak_ch13.pdf&page=1&title=PHAK%20Ch.13%20-%20Introduction
- Observations (13-2): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/15_phak_ch13.pdf&page=2&title=PHAK%20Ch.13%20-%20Observations
- Service Outlets (13-4): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/15_phak_ch13.pdf&page=4&title=PHAK%20Ch.13%20-%20Service%20Outlets
- Weather Briefings (13-5): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/15_phak_ch13.pdf&page=5&title=PHAK%20Ch.13%20-%20Weather%20Briefings
- Aviation Weather Reports (13-5): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/15_phak_ch13.pdf&page=5&title=PHAK%20Ch.13%20-%20Aviation%20Weather%20Reports
- Aviation Forecasts (13-9): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/15_phak_ch13.pdf&page=9&title=PHAK%20Ch.13%20-%20Aviation%20Forecasts
- Weather Charts (13-13): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/15_phak_ch13.pdf&page=13&title=PHAK%20Ch.13%20-%20Weather%20Charts
- ATC Radar Weather Displays (13-16): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/15_phak_ch13.pdf&page=16&title=PHAK%20Ch.13%20-%20ATC%20Radar%20Weather%20Displays
- Electronic Flight Displays (EFD)/Multi-Function Display (MFD) Weather (13-18): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/15_phak_ch13.pdf&page=18&title=PHAK%20Ch.13%20-%20Electronic%20Flight%20Displays%20%28EFD%29%2FMulti-Function%20Display%20%28MFD%29%20Weather
- Data Link Weather Products (13-23): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/15_phak_ch13.pdf&page=23&title=PHAK%20Ch.13%20-%20Data%20Link%20Weather%20Products
- Pilot Responsibility (13-24): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/15_phak_ch13.pdf&page=24&title=PHAK%20Ch.13%20-%20Pilot%20Responsibility
- Chapter Summary (13-24): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/15_phak_ch13.pdf&page=24&title=PHAK%20Ch.13%20-%20Chapter%20Summary

## Ch. 14 — Airport Operations
- Introduction (14-1): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/16_phak_ch14.pdf&page=1&title=PHAK%20Ch.14%20-%20Introduction
- Airport Categories (14-1): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/16_phak_ch14.pdf&page=1&title=PHAK%20Ch.14%20-%20Airport%20Categories
- Sources for Airport Data (14-3): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/16_phak_ch14.pdf&page=3&title=PHAK%20Ch.14%20-%20Sources%20for%20Airport%20Data
- Airport Markings and Signs (14-5): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/16_phak_ch14.pdf&page=5&title=PHAK%20Ch.14%20-%20Airport%20Markings%20and%20Signs
- Airport Lighting (14-16): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/16_phak_ch14.pdf&page=16&title=PHAK%20Ch.14%20-%20Airport%20Lighting
- Wind Direction Indicators (14-20): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/16_phak_ch14.pdf&page=20&title=PHAK%20Ch.14%20-%20Wind%20Direction%20Indicators
- Traffic Patterns (14-20): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/16_phak_ch14.pdf&page=20&title=PHAK%20Ch.14%20-%20Traffic%20Patterns
- Radio Communications (14-22): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/16_phak_ch14.pdf&page=22&title=PHAK%20Ch.14%20-%20Radio%20Communications
- Air Traffic Control (ATC) Services (14-24): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/16_phak_ch14.pdf&page=24&title=PHAK%20Ch.14%20-%20Air%20Traffic%20Control%20%28ATC%29%20Services
- Wake Turbulence (14-26): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/16_phak_ch14.pdf&page=26&title=PHAK%20Ch.14%20-%20Wake%20Turbulence
- Collision Avoidance (14-28): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/16_phak_ch14.pdf&page=28&title=PHAK%20Ch.14%20-%20Collision%20Avoidance
- Engineered Materials Arresting Systems (EMAS) (14-35): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/16_phak_ch14.pdf&page=35&title=PHAK%20Ch.14%20-%20Engineered%20Materials%20Arresting%20Systems%20%28EMAS%29
- Chapter Summary (14-37): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/16_phak_ch14.pdf&page=37&title=PHAK%20Ch.14%20-%20Chapter%20Summary

## Ch. 15 — Airspace
- Introduction (15-1): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/17_phak_ch15.pdf&page=1&title=PHAK%20Ch.15%20-%20Introduction
- Controlled Airspace (15-2): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/17_phak_ch15.pdf&page=2&title=PHAK%20Ch.15%20-%20Controlled%20Airspace
- Uncontrolled Airspace (15-3): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/17_phak_ch15.pdf&page=3&title=PHAK%20Ch.15%20-%20Uncontrolled%20Airspace
- Special Use Airspace (15-3): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/17_phak_ch15.pdf&page=3&title=PHAK%20Ch.15%20-%20Special%20Use%20Airspace
- Other Airspace Areas (15-4): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/17_phak_ch15.pdf&page=4&title=PHAK%20Ch.15%20-%20Other%20Airspace%20Areas
- Air Traffic Control and the National Airspace System (15-7): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/17_phak_ch15.pdf&page=7&title=PHAK%20Ch.15%20-%20Air%20Traffic%20Control%20and%20the%20National%20Airspace%20System
- Chapter Summary (15-11): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/17_phak_ch15.pdf&page=11&title=PHAK%20Ch.15%20-%20Chapter%20Summary

## Ch. 16 — Navigation
- Introduction (16-1): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/18_phak_ch16.pdf&page=1&title=PHAK%20Ch.16%20-%20Introduction
- Aeronautical Charts (16-2): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/18_phak_ch16.pdf&page=2&title=PHAK%20Ch.16%20-%20Aeronautical%20Charts
- Latitude and Longitude (Meridians and Parallels) (16-3): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/18_phak_ch16.pdf&page=3&title=PHAK%20Ch.16%20-%20Latitude%20and%20Longitude%20%28Meridians%20and%20Parallels%29
- Effect of Wind (16-8): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/18_phak_ch16.pdf&page=8&title=PHAK%20Ch.16%20-%20Effect%20of%20Wind
- Basic Calculations (16-11): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/18_phak_ch16.pdf&page=11&title=PHAK%20Ch.16%20-%20Basic%20Calculations
- Pilotage (16-12): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/18_phak_ch16.pdf&page=12&title=PHAK%20Ch.16%20-%20Pilotage
- Dead Reckoning (16-13): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/18_phak_ch16.pdf&page=13&title=PHAK%20Ch.16%20-%20Dead%20Reckoning
- Flight Planning (16-17): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/18_phak_ch16.pdf&page=17&title=PHAK%20Ch.16%20-%20Flight%20Planning
- Charting the Course (16-18): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/18_phak_ch16.pdf&page=18&title=PHAK%20Ch.16%20-%20Charting%20the%20Course
- Filing a VFR Flight Plan (16-21): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/18_phak_ch16.pdf&page=21&title=PHAK%20Ch.16%20-%20Filing%20a%20VFR%20Flight%20Plan
- Ground-Based Navigation (16-22): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/18_phak_ch16.pdf&page=22&title=PHAK%20Ch.16%20-%20Ground-Based%20Navigation
- Global Positioning System (16-30): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/18_phak_ch16.pdf&page=30&title=PHAK%20Ch.16%20-%20Global%20Positioning%20System
- Lost Procedures (16-34): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/18_phak_ch16.pdf&page=34&title=PHAK%20Ch.16%20-%20Lost%20Procedures
- Flight Diversion (16-34): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/18_phak_ch16.pdf&page=34&title=PHAK%20Ch.16%20-%20Flight%20Diversion
- Chapter Summary (16-35): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/18_phak_ch16.pdf&page=35&title=PHAK%20Ch.16%20-%20Chapter%20Summary

## Ch. 17 — Aeromedical Factors
- Introduction (17-1): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/19_phak_ch17.pdf&page=1&title=PHAK%20Ch.17%20-%20Introduction
- Obtaining a Medical Certificate (17-2): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/19_phak_ch17.pdf&page=2&title=PHAK%20Ch.17%20-%20Obtaining%20a%20Medical%20Certificate
- Health and Physiological Factors Affecting Pilot Performance (17-3): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/19_phak_ch17.pdf&page=3&title=PHAK%20Ch.17%20-%20Health%20and%20Physiological%20Factors%20Affecting%20Pilot%20Performance
- Vision in Flight (17-19): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/19_phak_ch17.pdf&page=19&title=PHAK%20Ch.17%20-%20Vision%20in%20Flight
- Chapter Summary (17-29): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/19_phak_ch17.pdf&page=29&title=PHAK%20Ch.17%20-%20Chapter%20Summary

## Appendices
- Appendix A: Performance Data for Cessna Model 172R and Challenger 605 (A-1): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/20_phak_appendices.pdf&page=1&title=PHAK%20App.%20A%20-%20Performance%20Data%20for%20Cessna%20Model%20172R%20and%20Challenger%20605
- Appendix B: Acronyms, Abbreviations, and NOTAM Contractions (B-1): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/20_phak_appendices.pdf&page=9&title=PHAK%20App.%20B%20-%20Acronyms%2C%20Abbreviations%2C%20and%20NOTAM%20Contractions
- Appendix C: Airport Signs and Markings (C-1): https://qdupper-bit.github.io/faa-viewer/index.html?file=pdfs/20_phak_appendices.pdf&page=21&title=PHAK%20App.%20C%20-%20Airport%20Signs%20and%20Markings
